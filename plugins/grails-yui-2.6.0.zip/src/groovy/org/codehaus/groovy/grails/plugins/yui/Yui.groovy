package org.codehaus.groovy.grails.plugins.yui;

class Yui {

    static version = "2.6.0"
    
}
